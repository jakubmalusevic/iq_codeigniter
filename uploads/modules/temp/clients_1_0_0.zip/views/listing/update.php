<form method="post" action="<?=base_url()?>clients/listing/update/<?=$item->id?>" class="modal-wrapper column-4" validate-form="true" validation-error="<?=$this->lang->line("please_check_marked_fields")?>">
	<div class="modal-header">
		<?=$this->lang->line("update_client")?>
	</div>	
	<div class="modal-content">
		<div class="inline-form-row">
			<div class="column-6">
				<label for="company_name"><?=$this->lang->line("company_name")?></label>
			</div>
			<div class="column-6">
				<input type="text" id="company_name" name="company_name" value="<?=$item->company_name?>" class="full-width" required-field="true" validation="[not-empty]" />
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="inline-form-row">
			<div class="column-6">
				<label for="contact_person"><?=$this->lang->line("contact_person")?></label>
			</div>
			<div class="column-6">
				<input type="text" id="contact_person" name="contact_person" value="<?=$item->contact_person?>" class="full-width" required-field="true" validation="[not-empty]" />
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="inline-form-row">
			<div class="column-6">
				<label for="address"><?=$this->lang->line("address")?></label>
			</div>
			<div class="column-6">
				<textarea id="address" name="address" class="full-width"><?=$item->address?></textarea>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="inline-form-row">
			<div class="column-6">
				<label for="email"><?=$this->lang->line("email")?></label>
			</div>
			<div class="column-6">
				<input type="text" id="email" name="email" class="full-width" value="<?=$item->email?>" required-field="true" validation="[email]" />
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="inline-form-row">
			<div class="column-6">
				<label for="phone_number"><?=$this->lang->line("phone_number")?></label>
			</div>
			<div class="column-6">
				<input type="text" id="phone_number" name="phone_number" value="<?=$item->phone_number?>" class="full-width" />
			</div>
			<div class="clearfix"></div>
		</div>
		<?php
		$this->event->register("ClientUpdateFormRow",$item);
		?>
		<div class="form-error-handler" error-handler="true"></div>
	</div>	
	<div class="modal-footer">
		<input type="submit" value="<?=$this->lang->line("update")?>" class="button medium-button primary-button" />
		<a href="#" class="button medium-button secondary-button close-modal-window">
			<?=$this->lang->line("close")?>
		</a>		
	</div>
</form>
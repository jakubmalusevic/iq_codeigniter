<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ClientsModel extends CI_Model {

	function __construct() {
		parent::__construct();
		$this->load->database();
	}
	
	function getItems($params=array(),$sorting=array(),$page=-1) {  		
		$return=array();		
		$this->db->select("clients.*");
		$this->db->from("clients as clients");
		if (isset($params['company_name'])) {
			if (str_replace(" ","",$params['company_name'])!="") {
				$this->db->where("clients.`company_name` LIKE '%".$this->db->escape_like_str($params['company_name'])."%'",NULL,false);
			}
		}
		if (isset($params['contact_person'])) {
			if (str_replace(" ","",$params['contact_person'])!="") {
				$this->db->where("clients.`contact_person` LIKE '%".$this->db->escape_like_str($params['contact_person'])."%'",NULL,false);
			}
		}
		if (isset($params['address'])) {
			if (str_replace(" ","",$params['address'])!="") {
				$this->db->where("clients.`address` LIKE '%".$this->db->escape_like_str($params['address'])."%'",NULL,false);
			}
		}
		if (isset($params['email'])) {
			if (str_replace(" ","",$params['email'])!="") {
				$this->db->where("clients.`email` LIKE '%".$this->db->escape_like_str($params['email'])."%'",NULL,false);
			}
		}
		if (isset($params['phone_number'])) {
			if (str_replace(" ","",$params['phone_number'])!="") {
				$this->db->where("clients.`phone_number` LIKE '%".$this->db->escape_like_str($params['phone_number'])."%'",NULL,false);
			}
		}					
		if (isset($sorting['sort-column']) && isset($sorting['sort-direction'])) {
			$this->db->order_by($sorting['sort-column'],$sorting['sort-direction']);
		} else {
			$this->db->order_by("clients.company_name","asc");
		}
		$this->event->register("BuildClientsQuery");
		$this->total_count=$this->db->get_total_count();
		if ($page!=-1) {
			$this->db->limit($this->pagination->count_per_page,$page*$this->pagination->count_per_page);
		}
		$query=$this->db->get();
		$return=$query->result();
		return $return;
    }
	
	function create($data){
		$this->event->register("BeforeCreateClient",$data);
    	$return=true;
    	$this->db->select("id");
    	$this->db->from("clients");
    	$this->db->where("company_name",$data['company_name']); 
    	$query=$this->db->get();
		$result=$query->result();
		if (count($result)>0) {
			$return=false;
			$this->notifications->setError("\"".$data['company_name']."\" ".$this->lang->line("company_name_already_used"));
		}
		if ($return) {
			$insert=array(
				"company_name"=>$data['company_name'],
				"contact_person"=>$data['contact_person'],
				"address"=>$data['address'],
				"email"=>$data['email'],
				"phone_number"=>$data['phone_number']
			);
			$this->db->insert("clients",$insert);	
			$item_id=$this->db->insert_id();
			$this->event->register("AfterCreateClient",$data,$item_id);
			$this->SystemLog->write("clients","listing","create",1,"Client \"".$data['company_name']."\" has been created in the system");	
		}
		return $return;
	}
	
	function getItem($item_id){
		$return=false;
		$this->db->select("clients.*");
		$this->db->from("clients");
		$this->db->where("clients.id",$item_id);
		$this->event->register("BuildClientQuery",$item_id);
    	$query=$this->db->get();
		$result=$query->result();
		if (count($result)>0) {
			$return=$result[0];
		}
		return $return;
	}
	
	function update($data,$item_id){
		$this->event->register("BeforeUpdateClient",$data,$item_id);
		$client=$this->getItem($item_id);	
    	$return=true;
    	$this->db->select("id");
    	$this->db->from("clients");
    	$this->db->where("company_name",$data['company_name']); 
    	$this->db->where("id !=",$item_id);
    	$query=$this->db->get();
		$result=$query->result();
		if (count($result)>0) {
			$return=false;
			$this->notifications->setError("\"".$data['company_name']."\" ".$this->lang->line("company_name_already_used"));
		}	
		if ($return) {
			$update=array(
				"company_name"=>$data['company_name'],
				"contact_person"=>$data['contact_person'],
				"address"=>$data['address'],
				"email"=>$data['email'],
				"phone_number"=>$data['phone_number']
			);
			$this->db->where("id",$item_id);
			$this->db->update("clients",$update);	
			$this->event->register("AfterUpdateClient",$data,$item_id);	
			$this->SystemLog->write("clients","listing","update",2,"Client \"".$client->company_name."\" has been updated in the system");
		}
		return $return;
	}

	function delete($item_id){
		$this->event->register("BeforeDeleteClient",$item_id);
		$client=$this->getItem($item_id);	
		$this->db->where("id",$item_id);
		$this->db->delete("clients");
		$this->event->register("AfterDeleteClient",$item_id);
		$this->SystemLog->write("clients","listing","delete",3,"Client \"".$client->full_name."\" has been deleted from the system");
		return true;
	}
    
}
?>
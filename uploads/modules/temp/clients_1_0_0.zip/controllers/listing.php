<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Listing extends MX_Controller {
	
	var $check_permissions=true;

	public function index(){							
		$this->view_data['page_title']=$this->lang->line("clients");
		$params=array();
		$get=$this->input->get(NULL, TRUE, TRUE);
		if (isset($get['apply_filters']) && isset($get['filter'])) {
			$params=$get['filter'];
		}			
		$sorting=array();
		if (isset($get['sort-column']) && @$get['sort-column']!="") {
			$sorting['sort-column']=$get['sort-column'];
			$sorting['sort-direction']="asc";
			if (isset($get['sort-direction'])) {
				if (strtolower($get['sort-direction'])=="asc" || strtolower($get['sort-direction'])=="desc") {
					$sorting['sort-direction']=$get['sort-direction'];
				}
			}
		}	
		$page=0;
		if (isset($get['page'])) {
			if (is_numeric($get['page']) && $get['page']>=0) {
				$page=$get['page'];
			}
		}				
		$this->load->model('ClientsModel');
		$this->view_data['items']=$this->ClientsModel->getItems($params,$sorting,$page);
		$total_items=$this->ClientsModel->total_count;
		$this->pagination->setNumbers(count($this->view_data['items']),$total_items);
		$sidebar_params=array(
			"name"=>"left-sidebar",
			"title"=>$this->lang->line("filters"),
			"position"=>"left",
			"is_filter"=>true,
			"filter_action"=>base_url()."clients/listing/index",
			"submit_button"=>$this->lang->line("apply_filters"),
			"reset_button"=>$this->lang->line("reset_filters"),
			"filter_event"=>"ClientsFilterFormRow",
			"elements"=>array(
				array(
					"type"=>"text",
					"name"=>"company_name",
					"placeholder"=>$this->lang->line("search_company_name")
				),
				array(
					"type"=>"text",
					"name"=>"contact_person",
					"placeholder"=>$this->lang->line("search_contact_person")
				),
				array(
					"type"=>"text",
					"name"=>"address",
					"placeholder"=>$this->lang->line("search_address")
				),
				array(
					"type"=>"text",
					"name"=>"email",
					"placeholder"=>$this->lang->line("search_email")
				),
				array(
					"type"=>"text",
					"name"=>"phone_number",
					"placeholder"=>$this->lang->line("search_phone_number")
				)
			)
		);
		$this->sidebar->register($sidebar_params);	
		$this->load->view('general/header',$this->view_data);
		$this->load->view('listing/index',$this->view_data);
		$this->load->view('general/footer',$this->view_data);
	}
	
	public function create(){
		$this->load->model('ClientsModel');
		if ($data=$this->input->post(NULL, TRUE)) {
			if ($this->ClientsModel->create($data)) {
				$this->notifications->setMessage($this->lang->line("client_created_successfully"));
			}
			redirect($_SERVER['HTTP_REFERER']);
		}	
		$this->load->view('listing/create',$this->view_data);
	}	
	
	public function update(){
		$this->load->model('ClientsModel');
		if ($this->uri->segment(4)!==FALSE) {
			if ($data=$this->input->post(NULL, TRUE)) {
				if ($this->ClientsModel->update($data,$this->uri->segment(4))) {
					$this->notifications->setMessage($this->lang->line("client_updated_successfully"));
				}
				redirect($_SERVER['HTTP_REFERER']);
			}		
			$this->view_data['item']=$this->ClientsModel->getItem($this->uri->segment(4));	
			if ($this->view_data['item']===false) {
				$this->load->view('errors/notfound',$this->view_data);
			} else {
				$this->load->view('listing/update',$this->view_data);
			}
		} else {
			$this->load->view('errors/wrongparameters',$this->view_data);
		}
	}		
	
	public function delete(){
		if ($this->uri->segment(4)!==FALSE) {
			$this->load->model('ClientsModel');
			if ($this->ClientsModel->delete($this->uri->segment(4))) {
				$this->notifications->setMessage($this->lang->line("client_deleted_successfully"));
			}			
		} else {
			$this->notifications->setError($this->lang->line("wrong_parameters"));
		}
		redirect($_SERVER['HTTP_REFERER']);
	}	
	
}